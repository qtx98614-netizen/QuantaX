### New in v64.4 (Unified Rebase)
- Secrets-only alerting, Grafana provisioning, smoke tests, Prometheus rules, RocksDB tuning, DR/SOPS packs, runbooks
- Helm chart **0.4.4** (appVersion v64.4)


### New in v64.5 (Unified)
- Embedded observability templates, secret guards, and Grafana jobs
- Helm chart **0.4.5** (appVersion v64.5)


### New in v64.5.1
- Added GitHub Actions workflow `quantax-ci-smoke` (lint → template → helm-unittest → KinD smoke)
- Makefile with CI targets (`untar`, `lint`, `template`, `unittest`, `kind-smoke`)


### New in v64.5.2
- CI artifacts: rendered manifests, helm-unittest JUnit, KinD smoke cluster dump
- Added `docs/ROADMAP_v65.0.md` and `packs/v65.0/*` scaffolds


### New in v65.0
- **Treasury Router v2** CRD/CR, circuit breakers, streaming splits
- **ZK-KYC v2** multi-provider config & rate-limits
- **AI-Ops v1** anomaly scout CronJob
- **Self-Healing** HPA/PDB and pre-upgrade safety gate
- **Persistence** snapshot CronJob
- **APIs & SDKs** stubs (Go/Python/TS) + OpenAPI skeleton
- **Governance v3** proposal template + CLI submit stub
- **Supply Chain** SBOM + optional Cosign signing workflow
- Helm chart **0.5.0** (appVersion v65.0)


### New in v65.0.1
- Consolidated v65.0 pack templates under `templates/packs/*`
- Helm chart **0.5.1** (appVersion v65.0.1)
- Added `tools/render.sh` (one-command `helm template`) and CI artifact for rendered manifests


### New in v65.1
- **ZK-KYC router** Deployment/Service/ServiceMonitor (exposes /verify & /metrics)
- **Treasury circuit-breaker alerts** (circuit open + outflow-rate high)
- **SDKs**: HMAC-signed POST helpers (Go/Python/TS) adding `X-QTX-Signature`
- **Supply-chain CI**: SBOM presence gate + optional Cosign verify step
- Helm chart **0.5.2** (appVersion v65.1)


### New in v65.2
- KYC Router **Ingress** (optional) with class/host/TLS toggles
- Per-provider **KYC error-budget SLO** Prometheus rules
- **Grafana**: KYC approvals/rejections stat panels added
- **Governance mock**: /gov/submit service for end-to-end CLI testing
- Helm chart **0.5.3** (appVersion v65.2)


### New in v65.3
- **Router Ingress TLS** via Cert-Manager (ClusterIssuer + Ingress annotations & secret)
- **Grafana**: Provider SLO bar gauge panel; alert annotations link directly to KYC dashboard panel
- **KYC Router mock**: readiness/liveness & `/metrics` path on ServiceMonitor
- **SDKs**: typed signed POST with simple retries (Go/Python/TS)
- Helm chart **0.5.4** (appVersion v65.3)


### New in v65.4
- **Umbrella chart** (`helm/quantax-umbrella`): optional cert-manager dependency + vendored core chart
- **Grafana**: KYC dashboard default time → 1h and post-install provision check job
- **KYC Router**: provider health CronJob and rate-limit SLO rules
- **Governance**: dry-run mode exposed via mock env
- Helm chart **0.5.5** (appVersion v65.4)


### New in v65.5
- **CLI**: `--dry-run` routes to `/gov/dry-run`
- **Provider health**: per-endpoint health with retries & jitter
- **Tenant rate limiting**: config + utilization metrics + alert with dashboard deep-link
- **Grafana**: Tenant drill-down panel (id=11)
- Helm chart **0.5.6** (appVersion v65.5)


### New in v65.6
- **Metrics Exporter**: emits provider & tenant rate-limit gauges (+ ServiceMonitor)
- **Router Autoscaling**: optional **KEDA** ScaledObject (RPS/SLO triggers) or HPA fallback
- **Blackbox Exporter**: Deployment + Probe for provider synthetic checks
- Helm chart **0.5.7** (appVersion v65.6)
- CLI: dry-run switch already available from v65.5


### New in v65.7
- **Umbrella**: optional **KEDA** subchart (like cert-manager) via `kedaUmbrella.enabled`
- **Alerts**: Grafana deep-links ensured for Tenant RL alerts (panel 11)
- **Router**: request sampling (probability) + OTEL exporter env; latency histogram panel (id 12)
- **CLI**: experimental `--fido2` hardware-key signing (requires `python-fido2` on caller env)
- Helm chart **0.5.8** (appVersion v65.7)


### New in v65.8
- **Umbrella**: optional **OpenTelemetry Collector** subchart with OTLP receiver and Tempo/Jaeger exporters
- **SLOs**: Router **p95/p99 latency** alerts (+ optional per-tenant p95)
- **Grafana**: Per-tenant latency tables (panels 13 & 14)
- **CLI**: `--cosign-keyless` support (uses `cosign sign-blob` if available)
- Helm chart **0.5.9** (appVersion v65.8)


### New in v65.9
- **Umbrella**: optional **Tempo** and **Jaeger** subcharts for one-command tracing stacks
- **Tenant circuit-breaker**: config + Prometheus rules for trip recommendation
- **Grafana**: Anomaly z-score panel (requests)
- **CLI**: Governance YAML schema validation (JSON Schema v2020-12)
- **Playbooks/Runbooks**: added in `runbooks/`
- Core Helm chart **0.6.0** (appVersion v65.9)


### New in v66.0
- **Grafana**: Tempo datasource provisioning + trace dashboard (`quantax-traces`)
- **On-Call**: Guided dashboard (`quantax-oncall`) with embedded runbook links
- **Prometheus**: p95/p99 **recording rules** for fast eval; KEDA latency trigger wired
- **Router**: tenant circuit **enforcement stub** (mounts config, enables env flags)
- **Helm chart**: 0.6.1 (appVersion v66.0)
