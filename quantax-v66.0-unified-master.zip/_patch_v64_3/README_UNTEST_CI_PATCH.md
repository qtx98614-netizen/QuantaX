# Quantax Helm unittest + CI Patch (v64.3)

This patch adds:
- `helm/tests/*_test.yaml` (helm-unittest suite)
- `.github/workflows/chart-ci.yml` (lint → template → unittest → KinD smoke)
- `Makefile` targets: `untar`, `lint`, `template`, `unittest`, `kind-smoke`

## How to apply
1. Unzip this patch at the root of your Quantax repo:
   ```bash
   unzip quantax-v64.3-unittest-ci-patch.zip -d your-repo && cd your-repo
   ```
2. Ensure your chart package exists at `helm/quantax-helm-oneclick-*.tgz`.
3. Run tests locally:
   ```bash
   make unittest
   make kind-smoke
   ```
4. Commit and push. GitHub Actions will trigger `chart-ci`.
