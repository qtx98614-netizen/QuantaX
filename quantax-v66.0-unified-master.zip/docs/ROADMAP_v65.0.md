# QuantaX v65.0 — Feature Pack Roadmap

## 1) Treasury Router v2
- Streaming splits, time-weighted allocations, circuit-breakers, dry-run mode.

## 2) ZK-KYC Pack v2
- Multi-provider fallbacks, rate-limited attestations, proof caching.

## 3) AI-Ops Layer v1
- Anomaly detection on metrics/logs, auto-runbooks, SLO burn predictions.

## 4) Self-Healing Extensions
- Health gates, progressive delivery, automatic peer rebalancing.

## 5) Persistence & Snapshots
- RocksDB compaction policies by table, periodic state snapshots with Velero hooks.

## 6) API & SDKs
- REST/gRPC schema stabilization, language SDKs (Go, Python, TS) with typed models.

## 7) Governance v3
- On-chain param sets (fees/emissions), emergency pause, multi-stage voting.

## 8) Security
- Sig-validation hardening, supply chain SBOM, image signing/verify in CI.

---
**How to implement:** create `packs/v65.0/` modules; each pack must include Helm values, CRs, alerts, dashboards, and runbooks.
