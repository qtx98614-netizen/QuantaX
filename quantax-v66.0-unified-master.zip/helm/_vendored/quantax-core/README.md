# Quantax Helm One‑Click v0.2.0 (Self‑Healing)

## Install
```bash
helm upgrade --install quantax quantax-helm-oneclick-0.2.0.tgz   -n quantax --create-namespace   --set image.repository=europe-west4-docker.pkg.dev/YOUR_PROJECT_ID/quantax/quantax-node   --set image.tag=latest   --set persistence.storageClassName=premium-rwo   --set persistence.size=200Gi   --set secrets.projectNumber=YOUR_PROJECT_NUMBER   --set selfHealing.enabled=true   --set selfHealing.chaos.enabled=false
```
## Toggle
- `selfHealing.enabled=true|false`
- `selfHealing.chaos.enabled=true|false`
- Tuning: `stallSeconds`, `minPeers`, `unhealthyCount`, `pollSeconds`
