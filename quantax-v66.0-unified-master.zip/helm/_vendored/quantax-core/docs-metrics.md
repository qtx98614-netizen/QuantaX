

## KYC Router Metrics (v65.7)
- `quantax_kyc_latency_seconds` (histogram)
- `quantax_kyc_requests_total{status}` (counter)
- `quantax_kyc_rate_limit_per_minute{provider}` (gauge)
- `quantax_kyc_tenant_rate_limit_per_minute{tenant}` (gauge)
