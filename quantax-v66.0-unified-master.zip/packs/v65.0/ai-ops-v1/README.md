# ai-ops-v1

Pack scaffold. Add CRDs, Helm values, alerts, dashboards, runbooks.
