# governance-v3

Pack scaffold. Add CRDs, Helm values, alerts, dashboards, runbooks.
