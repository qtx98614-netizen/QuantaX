# self-healing-ext

Pack scaffold. Add CRDs, Helm values, alerts, dashboards, runbooks.
