# treasury-router-v2

Pack scaffold. Add CRDs, Helm values, alerts, dashboards, runbooks.
