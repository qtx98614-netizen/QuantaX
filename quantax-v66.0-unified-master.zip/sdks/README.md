# SDKs (Go, Python, TypeScript) — stubs
