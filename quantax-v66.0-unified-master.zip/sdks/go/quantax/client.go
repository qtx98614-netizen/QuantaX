package quantax

import (
  "net/http"
  "crypto/hmac"
  "crypto/sha256"
  "encoding/base64"
  "bytes"
)


import (
  "net/http"
)

type Client struct{ Base string; *http.Client }

func New(base string) *Client { return &Client{Base: base, Client: &http.Client{}} }

func (c *Client) PostSigned(path string, body []byte, key []byte) (*http.Response, error) {
  mac := hmac.New(sha256.New, key)
  mac.Write(body)
  sig := base64.StdEncoding.EncodeToString(mac.Sum(nil))
  req, _ := http.NewRequest("POST", c.Base+path, bytes.NewReader(body))
  req.Header.Set("X-QTX-Signature", sig)
  return c.Do(req)
}

func (c *Client) PostSignedRetry(path string, body []byte, key []byte, retries int) (*http.Response, error) {
  var resp *http.Response
  var err error
  for i:=0;i<retries;i++ {
    resp, err = c.PostSigned(path, body, key)
    if err == nil && resp.StatusCode < 500 {
      return resp, nil
    }
    time.Sleep(time.Duration(500*(1<<i)) * time.Millisecond)
  }
  return resp, err
}
