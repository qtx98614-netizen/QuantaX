import requests

class Client:
    def __init__(self, base: str): self.base = base
    def status(self): return requests.get(self.base + "/status", timeout=5).json()

def _sign_hmac(payload: bytes, key: str) -> str:
    import hmac, hashlib, base64
    return base64.b64encode(hmac.new(key.encode(), payload, hashlib.sha256).digest()).decode()

def post_signed(self, path: str, body: dict, key: str):
    import json
    data = json.dumps(body).encode()
    sig = _sign_hmac(data, key)
    return requests.post(self.base + path, data=data, headers={"X-QTX-Signature": sig}, timeout=10)

from typing import Any, Dict
import time

def post_signed_retry(self, path: str, body: Dict[str, Any], key: str, retries: int = 3, backoff: float = 0.5):
    for i in range(retries):
        r = self.post_signed(path, body, key)
        if r.status_code < 500:
            return r
        time.sleep(backoff * (2 ** i))
    return r
