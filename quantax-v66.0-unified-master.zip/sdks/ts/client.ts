export class Client {
  constructor(public base: string) {}
  async status(): Promise<any> {
    const res = await fetch(this.base + "/status");
    return res.json();
  }
}

function signHmac(body: string, key: string): string {
  const enc = new TextEncoder();
  const cryptoObj = (globalThis as any).crypto || require('crypto').webcrypto;
  const data = enc.encode(body);
  const keyData = enc.encode(key);
  // Node: use crypto lib; browser: assume server-side signing or WebCrypto subtle import
  if (cryptoObj && cryptoObj.subtle) { /* omitted for brevity */ }
  const nodeCrypto = require('crypto');
  const hmac = nodeCrypto.createHmac('sha256', key).update(body).digest('base64');
  return hmac;
}

export async function postSigned(base: string, path: string, body: any, key: string) {
  const payload = JSON.stringify(body);
  const sig = signHmac(payload, key);
  const res = await fetch(base + path, { method: 'POST', body: payload, headers: { 'X-QTX-Signature': sig }});
  return res.json();
}

export async function postSignedRetry(base: string, path: string, body: any, key: string, retries=3, backoff=500) {
  let last: any;
  for (let i=0;i<retries;i++) {
    try { return await postSigned(base, path, body, key); }
    catch (e) { last = e; await new Promise(r=>setTimeout(r, backoff*Math.pow(2,i))); }
  }
  throw last;
}
