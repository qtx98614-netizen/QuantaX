#!/usr/bin/env python3
import sys, json, yaml, argparse, time, hmac, hashlib, base64, requests

def sign(payload: bytes, key: bytes) -> str:
    return base64.b64encode(hmac.new(key, payload, hashlib.sha256).digest()).decode()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--node", required=True, help="Quantax node base url")
    ap.add_argument("--dry-run", action="store_true", help="Hit /gov/dry-run instead of /gov/submit")
    ap.add_argument("--key", help="HMAC key (demo)")
    ap.add_argument("--fido2", action="store_true", help="Use a FIDO2 hardware key to sign (experimental)")
    ap.add_argument("--cosign-keyless", action="store_true", help="Use Cosign keyless to sign the proposal (requires cosign & OIDC)")
    ap.add_argument("proposal", help="YAML proposal file")
    args = ap.parse_args()
    doc = yaml.safe_load(open(args.proposal, "r").read())
    body = json.dumps(doc).encode()
    if args.fido2:
        try:
            from fido2.client import Fido2Client
            from fido2.hid import CtapHidDevice
            dev = next(CtapHidDevice.list_devices())
            client = Fido2Client(dev, "https://quantax.local")
            # Demo: sign hash; in real flow, use WebAuthn assertions with RP, user handle
            import hashlib, base64
            digest = hashlib.sha256(body).digest()
            # Placeholder: we don't complete an assertion ceremony here
            sig = base64.b64encode(digest).decode()
        except Exception as e:
            raise SystemExit(f"FIDO2 signing failed: {e}")
    else:
        sig = sign(body, (args.key or '').encode())
    headers = {"X-QTX-Signature": sig}
    endpoint = "/gov/dry-run" if args.dry_run else "/gov/submit"
    r = requests.post(args.node + endpoint, data=body, headers=headers, timeout=10)
    print(r.status_code, r.text)

if __name__ == "__main__":
    main()
