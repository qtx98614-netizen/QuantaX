#!/usr/bin/env bash
set -euo pipefail
CHART_TGZ="${1:-helm/quantax-helm-oneclick-0.5.1.tgz}"
OUT="${2:-artifacts/rendered.yaml}"
rm -rf helm/chart && mkdir -p helm/chart artifacts
tar -xzf "$CHART_TGZ" -C helm/chart
helm template quantax helm/chart -n quantax --set observability.enabled=false > "$OUT"
echo "[render] wrote $OUT"
